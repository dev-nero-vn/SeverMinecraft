#!/usr/bin/env python3
"""Summarize Samsung APK metadata without publishing decompiled source."""
from __future__ import annotations
import re
import sys
from pathlib import Path

badging_path, permissions_path, source_dir, output_path = map(Path, sys.argv[1:5])
badging = badging_path.read_text(errors="replace") if badging_path.exists() else ""
permissions = permissions_path.read_text(errors="replace") if permissions_path.exists() else ""
package = re.search(r"package: name='([^']+)'", badging)
version = re.search(r"versionName='([^']+)'", badging)
version_code = re.search(r"versionCode='([^']+)'", badging)
min_sdk = re.search(r"sdkVersion:'([^']+)'", badging)
target_sdk = re.search(r"targetSdkVersion:'([^']+)'", badging)
perm_names = sorted(set(re.findall(r"uses-permission(?:-sdk-\d+)?:(?: name=)?'([^']+)'", permissions)))
classes: list[str] = []
tokens = {
    "Overlay / cửa sổ nổi": ["TYPE_APPLICATION_OVERLAY", "WindowManager", "Floating"],
    "Bảng công cụ / game": ["GameTools", "GameBooster", "GameMode", "GameTool"],
    "FPS / hiệu năng": ["FPS", "FrameRate", "Performance", "Thermal", "Cpu", "Gpu"],
    "Quay / chụp màn hình": ["MediaProjection", "ScreenRecord", "Screenshot", "Capture"],
    "Cảm ứng / điều khiển": ["Touch", "Gesture", "Input", "GamePad", "Controller"],
    "Âm thanh / micro": ["Audio", "Mic", "Sound", "Vibration"],
}
files = list(source_dir.rglob("*.java")) if source_dir.exists() else []
for f in files:
    rel = f.relative_to(source_dir).as_posix()
    if any(any(t.lower() in rel.lower() for t in group) for group in tokens.values()):
        classes.append(rel)

privileged = [
    "android.permission.ACCESS_SURFACE_FLINGER",
    "android.permission.CAPTURE_AUDIO_OUTPUT",
    "android.permission.DEVICE_POWER",
    "android.permission.FORCE_STOP_PACKAGES",
    "android.permission.INJECT_EVENTS",
    "android.permission.INTERNAL_SYSTEM_WINDOW",
    "android.permission.MANAGE_GAME_MODE",
    "android.permission.MANAGE_MEDIA_PROJECTION",
    "android.permission.READ_FRAME_BUFFER",
    "android.permission.READ_PRIVILEGED_PHONE_STATE",
    "android.permission.REAL_GET_TASKS",
    "android.permission.SET_PROCESS_LIMIT",
    "android.permission.STATUS_BAR",
    "android.permission.WRITE_SECURE_SETTINGS",
]
found_priv = [p for p in privileged if p in permissions]

lines = [
    "# Báo cáo phân tích APK Samsung Game Booster",
    "",
    "> Chỉ ghi metadata, tên thành phần và nhóm chức năng. Không phát hành mã nguồn/tài nguyên decompile.",
    "",
    "## Metadata",
    f"- Package: `{package.group(1) if package else 'không đọc được'}`",
    f"- Version: `{version.group(1) if version else 'không đọc được'}` (code `{version_code.group(1) if version_code else '?'}`)",
    f"- minSdk: `{min_sdk.group(1) if min_sdk else '?'}`",
    f"- targetSdk: `{target_sdk.group(1) if target_sdk else '?'}`",
    f"- Tổng quyền trong dump: **{len(perm_names)}**",
    "",
    "## Quyền đặc quyền có trong APK tham chiếu",
]
lines += [f"- `{p}`" for p in found_priv] or ["- Không tìm thấy trong file permissions dump."]
lines += [
    "",
    "## Nhóm class liên quan được phát hiện trong kết quả JADX",
]
lines += [f"- `{c}`" for c in classes[:100]] or ["- Chưa có kết quả decompile hoặc không tìm thấy tên phù hợp."]
lines += [
    "",
    "## Kết luận triển khai",
    "- APK tham chiếu sử dụng package riêng của Samsung và quyền hệ thống/đặc quyền.",
    "- APK độc lập có thể cung cấp overlay, lối tắt app, đồng hồ phiên và một số trạng thái thiết bị qua API Android công khai.",
    "- Không thể sao chép quyền chữ ký Samsung, thay thế Game Optimization Service, hoặc bảo đảm FPS thực/CPU-GPU tuning trên máy không có quyền hệ thống.",
    "- Mã nguồn decompile chỉ dùng kiểm tra nội bộ trong runner; artifact công khai chỉ chứa bản tóm tắt metadata này.",
]
output_path.write_text("\n".join(lines) + "\n")
print(output_path.read_text())
