package vn.nero.gamehud

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var startButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(0xFF080D14.toInt()) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(32), dp(22), dp(28))
        }
        scroll.addView(root)

        val brand = text("N E R O   /   GAME TOOLS", 13f, 0xFF69E0BD.toInt(), true)
        root.addView(brand, lp(match = true, bottom = 14))
        root.addView(text("Trợ lý chơi game\nngay trên màn hình", 30f, 0xFFF3F7FB.toInt(), true), lp(match = true, bottom = 10))
        root.addView(text("Một tay nắm nổi ở cạnh màn hình. Vuốt vào để mở bảng công cụ, theo dõi trạng thái thiết bị và mở ứng dụng nhanh mà không phải thoát trò chơi.", 15f, 0xFF9BAABC.toInt()), lp(match = true, bottom = 22))

        val statusCard = card()
        statusText = text("Đang kiểm tra quyền…", 14f, 0xFFE5EDF6.toInt(), true)
        statusCard.addView(text("TRẠNG THÁI", 11f, 0xFF69E0BD.toInt(), true), lp(match = true, bottom = 8))
        statusCard.addView(statusText, lp(match = true))
        root.addView(statusCard, lp(match = true, bottom = 18))

        startButton = button("BẬT THANH HUD", primary = true).apply {
            setOnClickListener {
                if (HudOverlayService.isRunning) {
                    stopService(Intent(this@MainActivity, HudOverlayService::class.java))
                    updateStatus()
                } else {
                    enableHud()
                }
            }
        }
        root.addView(startButton, lp(match = true, height = 54, bottom = 10))
        root.addView(button("CHỌN ỨNG DỤNG NHANH", primary = false).apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, ShortcutPickerActivity::class.java)) }
        }, lp(match = true, height = 52, bottom = 20))

        val metrics = card()
        metrics.addView(text("CÓ THỂ HIỂN THỊ", 11f, 0xFF69E0BD.toInt(), true), lp(match = true, bottom = 8))
        metrics.addView(text("• RAM thiết bị, pin, nhiệt độ pin và trạng thái nhiệt Android\n• Tần số làm tươi màn hình (Hz), đồng hồ phiên chơi có tạm dừng/tiếp tục\n• Không làm phiền (sau khi bạn tự cấp quyền)\n• Mở nhanh bảng âm lượng và cài đặt độ sáng\n• Tối đa 8 ứng dụng yêu thích hiển thị trên HUD", 14f, 0xFFE5EDF6.toInt()), lp(match = true))
        root.addView(metrics, lp(match = true, bottom = 14))

        val note = card()
        note.addView(text("LƯU Ý VỀ FPS", 11f, 0xFFFFC66D.toInt(), true), lp(match = true, bottom = 8))
        note.addView(text("Ứng dụng bên thứ ba không được cấp quyền hệ thống để đọc FPS thật của trò chơi khác trên mọi máy. Vì vậy HUD không bịa FPS. Hz màn hình được hiển thị riêng, không gọi nhầm là FPS. Một số tính năng tối ưu sâu của Samsung chỉ có trong Game Booster hệ thống.", 13f, 0xFFB8C5D3.toInt()), lp(match = true))
        root.addView(note, lp(match = true, bottom = 16))

        root.addView(text("Miễn phí • Không quảng cáo • Không tài khoản • Không quyền Internet", 12f, 0xFF718296.toInt()), lp(match = true))
        setContentView(scroll)
    }

    private fun enableHud() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_OVERLAY)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
            return
        }
        startHudService()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY && Settings.canDrawOverlays(this)) enableHud()
        updateStatus()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIFICATIONS) startHudService()
        updateStatus()
    }

    private fun startHudService() {
        val intent = Intent(this, HudOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        updateStatus()
    }

    private fun updateStatus() {
        val overlay = Settings.canDrawOverlays(this)
        val running = HudOverlayService.isRunning
        statusText.text = when {
            running -> "Thanh HUD đang bật. Chạm tay nắm ở cạnh màn hình để mở bảng."
            !overlay -> "Chưa cấp quyền hiển thị trên ứng dụng khác."
            else -> "Đã cấp quyền. Nhấn Bật thanh HUD để bắt đầu."
        }
        startButton.text = if (running) "TẮT THANH HUD" else "BẬT THANH HUD"
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        gravity = Gravity.START
        setLineSpacing(dp(3).toFloat(), 1f)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(17), dp(16), dp(17), dp(16))
        background = rounded(0xFF111B28.toInt(), 18)
    }

    private fun button(label: String, primary: Boolean) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(if (primary) 0xFF07140F.toInt() else 0xFFE7F1F9.toInt())
        background = rounded(if (primary) 0xFF69E0BD.toInt() else 0xFF172638.toInt(), 16)
        stateListAnimator = null
    }

    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun lp(match: Boolean, height: Int = -2, bottom: Int = 0) = LinearLayout.LayoutParams(
        if (match) LinearLayout.LayoutParams.MATCH_PARENT else LinearLayout.LayoutParams.WRAP_CONTENT,
        if (height == -2) LinearLayout.LayoutParams.WRAP_CONTENT else dp(height)
    ).apply { bottomMargin = dp(bottom) }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQ_OVERLAY = 201
        private const val REQ_NOTIFICATIONS = 202
    }
}
