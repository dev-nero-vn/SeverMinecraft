package vn.nero.gamehud

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.PowerManager
import android.os.SystemClock
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class HudOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var handleView: TextView? = null
    private var panelView: LinearLayout? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var receiverRegistered = false
    private var sessionStartedAt = 0L
    private var elapsedBeforePause = 0L
    private var timerRunning = true
    private var timerButton: TextView? = null
    private var dndButton: TextView? = null
    private val valueViews = mutableMapOf<String, TextView>()

    private val refreshReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_REFRESH) {
                if (panelView != null) rebuildFavorites()
                updateMetrics()
            }
        }
    }

    private val metricsRunnable = object : Runnable {
        override fun run() {
            updateMetrics()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        isRunning = true
        sessionStartedAt = SystemClock.elapsedRealtime()
        elapsedBeforePause = 0L
        timerRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        registerRefreshReceiver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (Settings.canDrawOverlays(this)) addHandleIfNeeded()
        handler.removeCallbacks(metricsRunnable)
        handler.post(metricsRunnable)
        return START_STICKY
    }

    private fun startAsForeground() {
        val openIntent = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 2, Intent(this, HudOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Nero Game HUD đang chạy")
            .setContentText("Chạm tay nắm ở cạnh màn hình để mở bảng công cụ")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Tắt HUD", stopIntent).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Nero Game HUD", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Thông báo khi thanh HUD nổi đang bật"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun registerRefreshReceiver() {
        val filter = IntentFilter(ACTION_REFRESH)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(refreshReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(refreshReceiver, filter)
        }
        receiverRegistered = true
    }

    private fun addHandleIfNeeded() {
        if (handleView != null) return
        val handle = TextView(this).apply {
            text = "N\n≡"
            textSize = 15f
            setTextColor(COLOR_INK)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setLineSpacing(dp(1).toFloat(), 0.95f)
            background = rounded(COLOR_ACCENT, 20, COLOR_ACCENT)
            elevation = dp(8).toFloat()
        }
        val params = WindowManager.LayoutParams(
            dp(44), dp(78),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = dp(2)
            y = 0
        }
        attachDragGesture(handle, params)
        try {
            windowManager.addView(handle, params)
            handleView = handle
            handleParams = params
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun attachDragGesture(view: View, params: WindowManager.LayoutParams) {
        var downX = 0f
        var downY = 0f
        var initialX = 0
        var initialY = 0
        var moved = false
        var lastDx = 0f
        val touchSlop = dp(8)
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    initialX = params.x
                    initialY = params.y
                    moved = false
                    lastDx = 0f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    lastDx = dx
                    if (kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop) moved = true
                    if (moved) {
                        val maxX = max(0, resources.displayMetrics.widthPixels - view.width)
                        val maxY = max(0, resources.displayMetrics.heightPixels / 2 - view.height / 2)
                        params.x = (initialX - dx).roundToInt().coerceIn(0, maxX)
                        params.y = (initialY + dy).roundToInt().coerceIn(-maxY, maxY)
                        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    // Tay nắm nằm bên phải: vuốt vào trong (sang trái) sẽ bung HUD.
                    if (!moved || lastDx < -touchSlop) togglePanel()
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
    }

    private fun togglePanel() {
        if (panelView == null) showPanel() else removePanel()
    }

    private fun showPanel() {
        if (panelView != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(COLOR_PANEL, 24, 0xFF304357.toInt())
            elevation = dp(16).toFloat()
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = TextView(this).apply {
            text = "NERO  /  GAME HUD"
            textSize = 13f
            setTextColor(COLOR_ACCENT)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(heading, LinearLayout.LayoutParams(0, dp(40), 1f))
        val close = TextView(this).apply {
            text = "×"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(COLOR_TEXT)
            background = rounded(0xFF223246.toInt(), 12)
            setOnClickListener { removePanel() }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(40), dp(40)))
        root.addView(header)
        root.addView(text("CÔNG CỤ NHANH · HOẠT ĐỘNG TRÊN MÀN HÌNH GAME", 10f, COLOR_MUTED, true), marginParams(bottom = 10))

        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        topRow.addView(metricCard("RAM ĐÃ DÙNG", "ram", "Đang đọc bộ nhớ thiết bị"), weightedParams())
        topRow.addView(spaceWidth(8))
        topRow.addView(metricCard("PIN", "battery", "Mức pin hiện tại"), weightedParams())
        val bottomRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottomRow.addView(metricCard("NHIỆT ĐỘ PIN", "temperature", "Nếu hệ thống cung cấp"), weightedParams())
        bottomRow.addView(spaceWidth(8))
        bottomRow.addView(metricCard("MÀN HÌNH", "refresh", "Tần số làm tươi"), weightedParams())
        grid.addView(topRow, marginParams(bottom = 8))
        grid.addView(bottomRow, marginParams(bottom = 8))
        val sessionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sessionRow.addView(metricCard("NHIỆT HỆ THỐNG", "thermal", "Trạng thái tản nhiệt Android"), weightedParams())
        sessionRow.addView(spaceWidth(8))
        sessionRow.addView(metricCard("PHIÊN CHƠI", "session", "Đồng hồ phiên chơi"), weightedParams())
        grid.addView(sessionRow)
        content.addView(grid, marginParams(bottom = 12))

        val timerControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        timerButton = quickAction("TẠM DỪNG", "Ⅱ") { toggleSessionTimer() }
        timerControls.addView(timerButton, LinearLayout.LayoutParams(0, dp(58), 1f))
        timerControls.addView(spaceWidth(8))
        timerControls.addView(quickAction("ĐẶT LẠI", "↻") { resetSessionTimer() }, LinearLayout.LayoutParams(0, dp(58), 1f))
        content.addView(timerControls, marginParams(bottom = 14))

        val fpsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(0xFF202638.toInt(), 15, 0xFF353B52.toInt())
        }
        fpsCard.addView(text("FPS THỰC CỦA GAME", 10f, 0xFFFFC66D.toInt(), true))
        fpsCard.addView(text("Chưa thể đọc bằng API Android thông thường", 13f, COLOR_TEXT, true), marginParams(top = 5))
        fpsCard.addView(text("Hz là tần số màn hình, không phải FPS game. HUD không hiển thị số FPS giả.", 11f, COLOR_MUTED), marginParams(top = 4))
        content.addView(fpsCard, marginParams(bottom = 14))

        content.addView(text("ĐIỀU KHIỂN NHANH", 11f, COLOR_ACCENT, true), marginParams(bottom = 7))
        val quickControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val dnd = quickAction("KHÔNG LÀM PHIỀN", "◉") { toggleDoNotDisturb() }
        dndButton = dnd
        quickControls.addView(dnd, LinearLayout.LayoutParams(0, dp(68), 1f))
        quickControls.addView(spaceWidth(7))
        quickControls.addView(quickAction("ÂM LƯỢNG", "♫") { openSettingsPanel(Settings.Panel.ACTION_VOLUME, Settings.ACTION_SOUND_SETTINGS) }, LinearLayout.LayoutParams(0, dp(68), 1f))
        quickControls.addView(spaceWidth(7))
        quickControls.addView(quickAction("ĐỘ SÁNG", "☼") { openSystemPanel(Settings.ACTION_DISPLAY_SETTINGS) }, LinearLayout.LayoutParams(0, dp(68), 1f))
        content.addView(quickControls, marginParams(bottom = 14))

        val shortcutsHeading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        shortcutsHeading.addView(text("ỨNG DỤNG NHANH", 11f, COLOR_ACCENT, true), LinearLayout.LayoutParams(0, dp(32), 1f))
        shortcutsHeading.addView(TextView(this).apply {
            text = "+ THÊM"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(COLOR_TEXT)
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = rounded(0xFF263B4D.toInt(), 10)
            setOnClickListener { openShortcutPicker() }
        })
        content.addView(shortcutsHeading, marginParams(bottom = 6))
        val favoritesContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        favoritesContainer.tag = FAVORITES_TAG
        content.addView(favoritesContainer)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("Miễn phí · Không quảng cáo · Không thu thập dữ liệu", 10f, COLOR_MUTED), marginParams(top = 10))

        val screenHeight = resources.displayMetrics.heightPixels
        val screenWidth = resources.displayMetrics.widthPixels
        val width = min(dp(344), screenWidth - dp(20)).coerceAtLeast(dp(260))
        val height = min(dp(560), screenHeight - dp(48)).coerceAtLeast(dp(360))
        val params = WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = dp(8)
            y = 0
        }
        try {
            windowManager.addView(root, params)
            panelView = root
            panelParams = params
            rebuildFavorites()
            updateMetrics()
        } catch (_: Exception) {
            panelView = null
        }
    }

    private fun metricCard(title: String, key: String, initial: String): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(11), dp(10), dp(10))
            background = rounded(0xFF172536.toInt(), 14, 0xFF293B50.toInt())
        }
        card.addView(text(title, 9f, COLOR_MUTED, true))
        val value = text("—", 20f, COLOR_TEXT, true)
        valueViews[key] = value
        card.addView(value, marginParams(top = 4))
        card.addView(text(initial, 9f, COLOR_MUTED), marginParams(top = 3))
        return card
    }

    private fun rebuildFavorites() {
        val root = panelView ?: return
        val container = root.findViewWithTag<LinearLayout>(FAVORITES_TAG) ?: return
        container.removeAllViews()
        val favorites = getSharedPreferences(PREFS, MODE_PRIVATE)
            .getStringSet(KEY_FAVORITES, emptySet())?.toList().orEmpty()
        if (favorites.isEmpty()) {
            container.addView(text("Chưa có ứng dụng. Nhấn + THÊM để chọn tối đa 8 app.", 12f, COLOR_MUTED), marginParams(bottom = 4))
            return
        }
        favorites.take(8).forEach { packageName ->
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(7), dp(10), dp(7))
                    background = rounded(0xFF172536.toInt(), 12)
                    val icon = ImageView(this@HudOverlayService).apply {
                        try { setImageDrawable(packageManager.getApplicationIcon(packageName)) }
                        catch (_: Exception) { setImageResource(android.R.drawable.sym_def_app_icon) }
                    }
                    addView(icon, LinearLayout.LayoutParams(dp(30), dp(30)))
                    val labelText = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(packageName, 0)).toString() }
                        catch (_: Exception) { packageName }
                    addView(text(labelText, 13f, COLOR_TEXT, true).apply { setPadding(dp(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
                    addView(text("MỞ", 10f, COLOR_ACCENT, true))
                    setOnClickListener {
                        try {
                            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(launch)
                        } catch (_: Exception) { }
                    }
                    setOnLongClickListener {
                        val updated = favorites.toMutableSet().apply { remove(packageName) }
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putStringSet(KEY_FAVORITES, updated).apply()
                        rebuildFavorites()
                        true
                    }
                }
                container.addView(row, marginParams(bottom = 6))
            }
        }
    }

    private fun openShortcutPicker() {
        try {
            startActivity(Intent(this, ShortcutPickerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { }
    }

    private fun updateMetrics() {
        if (valueViews.isEmpty()) return
        val activityManager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memory)
        val used = (memory.totalMem - memory.availMem).coerceAtLeast(0L)
        valueViews["ram"]?.text = "${percent(used, memory.totalMem)}%"
        val elapsedMs = elapsedBeforePause + if (timerRunning) (SystemClock.elapsedRealtime() - sessionStartedAt).coerceAtLeast(0L) else 0L
        valueViews["session"]?.text = formatDuration(elapsedMs / 1000L)
        updateTimerButton()

        val power = getSystemService(POWER_SERVICE) as PowerManager
        valueViews["thermal"]?.text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            when (power.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "ỔN ĐỊNH"
                PowerManager.THERMAL_STATUS_LIGHT -> "HƠI ẤM"
                PowerManager.THERMAL_STATUS_MODERATE -> "ẤM"
                PowerManager.THERMAL_STATUS_SEVERE -> "NÓNG"
                PowerManager.THERMAL_STATUS_CRITICAL -> "RẤT NÓNG"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "KHẨN CẤP"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "SẮP TẮT"
                else -> "KHÔNG RÕ"
            }
        } else "Không hỗ trợ"

        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (battery != null) {
            val level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            val percent = if (level >= 0) (level * 100f / scale).roundToInt() else -1
            valueViews["battery"]?.text = if (percent >= 0) "$percent%" else "—"
            val temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            valueViews["temperature"]?.text = if (temp != Int.MIN_VALUE && temp > 0) "${temp / 10f}°C" else "—"
        }

        val display = (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        val hz = display?.mode?.refreshRate ?: 0f
        valueViews["refresh"]?.text = if (hz > 0f) "${hz.roundToInt()} Hz" else "—"
        updateDndButton()
    }


    private fun toggleSessionTimer() {
        if (timerRunning) {
            elapsedBeforePause += (SystemClock.elapsedRealtime() - sessionStartedAt).coerceAtLeast(0L)
            timerRunning = false
        } else {
            sessionStartedAt = SystemClock.elapsedRealtime()
            timerRunning = true
        }
        updateMetrics()
    }

    private fun resetSessionTimer() {
        elapsedBeforePause = 0L
        sessionStartedAt = SystemClock.elapsedRealtime()
        timerRunning = false
        updateMetrics()
    }

    private fun updateTimerButton() {
        timerButton?.text = if (timerRunning) "Ⅱ\nTẠM DỪNG" else "▶\nTIẾP TỤC"
    }

    private fun formatDuration(seconds: Long): String {
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60
        return if (hours > 0) String.format("%02d:%02d:%02d", hours, minutes, secs)
        else String.format("%02d:%02d", minutes, secs)
    }

    private fun updateDndButton() {
        val button = dndButton ?: return
        val manager = getSystemService(NotificationManager::class.java)
        val hasAccess = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && manager.isNotificationPolicyAccessGranted
        button.text = when {
            !hasAccess -> "◉\nKHÔNG LÀM PHIỀN\nCẤP QUYỀN"
            manager.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_PRIORITY -> "◉\nĐANG BẬT\nKHÔNG LÀM PHIỀN"
            else -> "◉\nKHÔNG LÀM PHIỀN"
        }
    }

    private fun toggleDoNotDisturb() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        if (!manager.isNotificationPolicyAccessGranted) {
            openSystemPanel(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return
        }
        try {
            val next = if (manager.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_PRIORITY) {
                NotificationManager.INTERRUPTION_FILTER_ALL
            } else {
                NotificationManager.INTERRUPTION_FILTER_PRIORITY
            }
            manager.setInterruptionFilter(next)
        } catch (_: SecurityException) {
            openSystemPanel(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
        }
        handler.postDelayed({ updateDndButton() }, 350L)
    }

    private fun openSettingsPanel(panelAction: String, fallbackAction: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                startActivity(Intent(panelAction).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) { }
        }
        openSystemPanel(fallbackAction)
    }

    private fun openSystemPanel(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) { }
        }
    }

    private fun quickAction(title: String, symbol: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = "$symbol\n$title"
        textSize = 10f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(COLOR_TEXT)
        setPadding(dp(4), dp(8), dp(4), dp(8))
        background = rounded(0xFF172536.toInt(), 13, 0xFF293B50.toInt())
        setOnClickListener { onClick() }
    }

    private fun percent(used: Long, total: Long): Int = if (total > 0L) ((used * 100.0 / total).roundToInt()).coerceIn(0, 100) else 0

    private fun removePanel() {
        panelView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        panelView = null
        panelParams = null
        valueViews.clear()
    }

    override fun onDestroy() {
        handler.removeCallbacks(metricsRunnable)
        removePanel()
        handleView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        handleView = null
        handleParams = null
        if (receiverRegistered) {
            try { unregisterReceiver(refreshReceiver) } catch (_: Exception) { }
            receiverRegistered = false
        }
        isRunning = false
        instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setLineSpacing(dp(2).toFloat(), 1f)
    }

    private fun rounded(color: Int, radius: Int, stroke: Int = color) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun marginParams(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = dp(top)
        bottomMargin = dp(bottom)
    }

    private fun weightedParams() = LinearLayout.LayoutParams(0, dp(82), 1f)
    private fun spaceWidth(width: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(width), 1) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val PREFS = "nero_game_hud_prefs"
        const val KEY_FAVORITES = "favorite_packages"
        const val ACTION_REFRESH = "vn.nero.gamehud.REFRESH_HUD"
        private const val ACTION_STOP = "vn.nero.gamehud.STOP_HUD"
        private const val CHANNEL_ID = "nero_game_hud_channel"
        private const val NOTIFICATION_ID = 7132
        private const val FAVORITES_TAG = "hud_favorites_container"
        private const val COLOR_ACCENT = 0xFF69E0BD.toInt()
        private const val COLOR_INK = 0xFF07140F.toInt()
        private const val COLOR_PANEL = 0xFF0D1622.toInt()
        private const val COLOR_TEXT = 0xFFF3F7FB.toInt()
        private const val COLOR_MUTED = 0xFF91A3B7.toInt()

        @Volatile var isRunning: Boolean = false
            private set
        @Volatile private var instance: HudOverlayService? = null

        fun refreshRunningPanel() {
            instance?.let { service ->
                service.sendBroadcast(Intent(ACTION_REFRESH).setPackage(service.packageName))
            }
        }
    }
}
