plugins {
    id("com.android.application")
}

android {
    namespace = "vn.nero.gamehud"
    compileSdk = 37

    defaultConfig {
        applicationId = "vn.nero.gamehud"
        minSdk = 26
        targetSdk = 37
        versionCode = 2
        versionName = "1.0.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        buildConfig = true
    }
}
